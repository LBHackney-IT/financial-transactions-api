namespace TransactionsApi.V1.Controllers
{
    public static class Constants
    {
        public const string CorrelationId = "x-correlation-id";
    }
}
