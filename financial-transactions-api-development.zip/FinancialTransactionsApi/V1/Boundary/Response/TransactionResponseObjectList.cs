using System.Collections.Generic;

namespace TransactionsApi.V1.Boundary.Response
{
    public class TransactionResponseObjectList
    {
        public List<TransactionResponseObject> ResponseObjects { get; set; }
    }
}
