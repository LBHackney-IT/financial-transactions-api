CREATE TABLE example_table (
    created_at timestamp ,
    id SERIAL PRIMARY KEY
);
