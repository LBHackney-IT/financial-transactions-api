namespace TransactionsApi.Tests.V1.E2ETests
{
    //For guidance on writing integration tests see the wiki page https://github.com/LBHackney-IT/lbh-base-api/wiki/Integration-Tests
    public class ExampleTest : IntegrationTests<Startup>
    {

    }
}
